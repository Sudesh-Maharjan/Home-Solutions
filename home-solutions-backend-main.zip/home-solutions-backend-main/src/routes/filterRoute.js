// const express = require('express')
// const { filterbycategory } = require('../controllers/filterbyCategory')
// const router = express.Router()
// router.get("/filterbycategory",filterbycategory)

// module.exports=router

